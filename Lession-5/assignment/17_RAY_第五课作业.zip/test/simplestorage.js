var Payroll = artifacts.require("./Payroll.sol");

contract('Payroll', function(accounts) {

    const owner = accounts[0];
    const employId= accounts[1];
    const nowner = accounts[2];
    const salary = 8;
    const weiToEther = web3.toWei('1', 'ether');

    it("addemployee测试添加的新员工", function() {
      return Payroll.deployed().then(function(instance) {
        PayrollInstance = instance;
        return PayrollInstance.addEmployee(employId,salary,{from: owner});
      }).then(function() {
        return PayrollInstance.employees.call(employId);
      }).then(function(employee) {
        assert.equal(employee[0], employId, "员工地址添加错误");
        assert.equal(employee[1],web3.toWei(salary,'ether'),"工资添加错误")
      });
    });
    

    it("addemployee测试是合约创建者添加新员工",function(){
      return Payroll.deployed().then(function(instance) {
        PayrollInstance = instance;
      try{  
        PayrollInstance.addEmployee(employId,salary,{from: nowner});
      }catch(e){
        return e.toString();
      }
    })
});


  it("addemployee添加相同的员工",function(){
    return Payroll.deployed().then(function(instance) {
      PayrollInstance = instance;
      try{  
        PayrollInstance.addEmployee(employId,salary,{from: owner});
        PayrollInstance.addEmployee(employId,salary,{from: owner});
      }catch(e){
        return e.toString();
      }
    })
  });

  it("removeemployee测试删除员工", function() {
    return Payroll.deployed().then(function(instance) {
      PayrollInstance = instance;
      return PayrollInstance.addEmployee(employId,salary,{from : owner});
    }).then(function(){
       PayrollInstance.addFund({value:web3.toWei(20)});
       return PayrollInstance.removeEmployee(employId);
       }).then(function(){
        return PayrollInstance.employees.call(employId, {from : owner})      
    }).then(function(employee){
      assert.equal(employee[0], '0x0000000000000000000000000000000000000000', "删除员工不成功" );
    });
});

  it("removeemployee测试是合约创建者删除新员工", function() {
    return Payroll.deployed().then(function(instance) {
      PayrollInstance = instance;
      PayrollInstance.addEmployee(employId,salary,{from: owner});
    }).then(function(){
      try{
        PayrollInstance.removeEmployee(employId,{from: nowner});
      }catch(e){
        return e.toString();
      }
    })
  });


  it("removeemployee测试删除不存在的新员工", function() {
    return Payroll.deployed().then(function(instance) {
      PayrollInstance = instance;
      try{
        PayrollInstance.removeEmployee(employId,{from: owner});
      }catch(e){
        return e.toString();
      }
    })
  });
});

