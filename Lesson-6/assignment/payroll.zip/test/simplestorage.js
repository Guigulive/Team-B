var Payroll = artifacts.require("./Payroll.sol");

contract('Payroll', function(accounts) {
  const owner = accounts[0];
  const employId= accounts[1];
  const nowner = accounts[2];
  const salary = 1;
    
  before(function(done){
      Payroll.deployed().then(function(instance) {
        var PayrollInstance = instance;
        PayrollInstance.addFund({
          from: owner,
          value: web3.toWei('10', 'ether')
        })
        console.log('0-0');
        done();
      })
    });
    
    beforeEach(async()=>{
      console.log('before every test in every file');
      // runs before each test in this block
      let PayrollInstance = await  Payroll.deployed();
        console.log('0-1');
      let employee = await  PayrollInstance.employees.call(employId, {from : owner})
        console.log('0-2');
        console.log(employee[0]);
        if( employee[0] !== '0x0000000000000000000000000000000000000000' )
        {
          console.log('0-3');
          await PayrollInstance.removeEmployee(employId,{from: owner});
        }
    })

    it("addemployee测试添加的新员工", function() {
      return Payroll.deployed().then(function(instance) {
        PayrollInstance = instance;
        console.log('1-1');
        return PayrollInstance.addEmployee(employId,salary,{from: owner});
      }).then(function() {
        return PayrollInstance.employees.call(employId);
      }).then(function(employee) {
        console.log('1-2');
        assert.equal(employee[0], employId, "员工地址添加错误");
        assert.equal(employee[1],web3.toWei(salary,'ether'),"工资添加错误")
      });
    })
    

    it("addemployee测试不是合约创建者添加新员工",async()=>{
      let PayrollInstance = await  Payroll.deployed();
        try{
          console.log('2-1');
          await PayrollInstance.addEmployee(employId, salary,{from: nowner});
      }catch(e){
        console.log('2-2');
        assert.include(e.toString(),"revert", "Error!!: 不是合约创建者添加新员工");
      }
    })
  


  it("addemployee添加相同的员工",async()=>{
    let PayrollInstance = await  Payroll.deployed();
      console.log('3-1');
       await PayrollInstance.addEmployee(employId,salary,{from: owner});
    try {
      console.log('3-2');
      await PayrollInstance.addEmployee(employId,salary,{from: owner})
    }catch(e){
      assert.include(e.toString(),"invalid opcode", "Error!!: 不能添加相同的员工");
      }
  })

  it("removeemployee测试删除员工", function() {
    return Payroll.deployed().then(function(instance) {
      PayrollInstance = instance;
      return PayrollInstance.addEmployee(employId,salary,{from : owner});
    }).then(function(){
       return PayrollInstance.removeEmployee(employId,{from: owner});
       }).then(function(){
        return PayrollInstance.employees.call(employId, {from : owner})      
    }).then(function(employee){
      assert.equal(employee[0], '0x0000000000000000000000000000000000000000', "删除员工不成功" );
    });
  })

  it("removeemployee测试不是合约创建者删除新员工", async()=>{
    let PayrollInstance = await  Payroll.deployed();
      await PayrollInstance.addEmployee(employId,salary,{from: owner});
      try{
        await  PayrollInstance.removeEmployee(employId,{from: nowner});
      }catch(error){
        assert.include(error.toString(),"revert", "Error!!: 不是合约创建者删除新员工");
      }
  })


  it("removeemployee测试删除不存在的新员工", async()=> {
    let PayrollInstance = await  Payroll.deployed();
      try{
        await PayrollInstance.removeEmployee(employId,{from: owner});
      }catch(error){
        assert.include(error.toString(),"invalid opcode", "Error!!: 删除不存在的新员工");
      }
    })
})

