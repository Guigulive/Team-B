import React, { Component } from 'react'
import PayrollContract from '../build/contracts/Payroll.json'
import getWeb3 from './utils/getWeb3'

import { Layout,Menu,Spin,Alert} from 'antd';

import Employer from './components/Employer';
import Employee from './components/Employee';


// import './css/oswald.css'
// import './css/open-sans.css'
// import './css/pure-min.css'
import 'antd/dist/antd.css';
import './App.css'

const {Header ,Content,Footer} = Layout;

class App extends Component {
  constructor(props) {
    super(props)

    this.state = {
      storageValue: 0,
      web3: null,
      mode:'employer'
    }
  }

  componentWillMount() {
    // Get network provider and web3 instance.
    // See utils/getWeb3 for more info.

    getWeb3
    .then(results => {
      this.setState({
        web3: results.web3
      })

      // Instantiate contract once web3 provided.
      this.instantiateContract()
    })
    .catch(() => {
      console.log('Error finding web3.')
    })
  }

  instantiateContract() {
    /*
     * SMART CONTRACT EXAMPLE
     *
     * Normally these functions would be called in the context of a
     * state management library, but for convenience I've placed them here.
     */

    const contract = require('truffle-contract')
    const Payroll = contract(PayrollContract)
    Payroll.setProvider(this.state.web3.currentProvider)

    // Declaring this for later so we can chain functions on SimpleStorage.
    var PayrollInstance

    // Get accounts.
    this.state.web3.eth.getAccounts((error, accounts) => {
      // Payroll.deployed().then((instance) => {
      //   PayrollInstance = instance

      //   // Stores a given value, 5 by default.
      //   return PayrollInstance.set(5, {from: accounts[0]})
      // }).then((result) => {
      //   // Get the value from the contract to prove it worked.
      //   return PayrollInstance.get.call(accounts[0])
      // }).then((result) => {
      //   // Update state with the result.
      //   return this.setState({ storageValue: result.c[0] })
      // })
      this.setState({
        account:accounts[0],
      });
      Payroll.deployed().then((instance)=>{
        PayrollInstance = instance;
        this.setState({
          payroll:instance
        });
      })
    })
  }

  onSelectTab=({key})=>{
    this.setState({
      mode:key
    });
  }

  renderContent = () =>{
    const {account,payroll,web3,mode} = this.state;
    if (!payroll){
      return <spin tip="Loading..."/>;
    }

    switch(mode){
      case 'employer':
        return <Employer account = {account} payroll ={payroll} web3={web3}/>
      case 'employee':
        return <Employee account = {account} payroll ={payroll} web3={web3}/>
      default :
        return <Alert message="" type="info" showIcon/>
    }
  }


  render() {
    return (
      <Layout>
        <Header className="header">
          <div className="logo">AccessFBA</div>
          <Menu theme="dark" mode="horizontal" defaultSelectedKeys={['employer']} style={{lineHeight:'64px'}} onSelect={this.onSelectTab}>
            <Menu.Item key="employer"></Menu.Item>
            <Menu.Item key="employee"></Menu.Item>
          </Menu>
          </Header>
          <Content style={{padding:'0 50px'}}>
            <Layout style={{padding:'24px 0',background:'#fff',minHeight:''}}>
              {/* {this.renderContent()} */}
            </Layout>
          </Content>
          <Footer style={{textAlign:'center'}}>
            Payroll 
          </Footer>
        </Layout>

    );
  }
}

export default App
